var express = require ('express');
var fs = require ('fs');
var router = express.Router ();
// handle multipart form data
const multer = require ('multer');
const path = require ('path');
const models = require ('../models');
const User = models.User;

const storage = multer.diskStorage ({
  destination: (req, file, cb) => {
    // set uploads directory
    cb (null, 'uploads/');
  },
  filename: (req, file, cb) => {
    // save file with current timestamp + user email + file extension
    cb (null, Date.now () + path.extname (file.originalname));
  },
});

// initialize the multer configuration
const upload = multer ({storage: storage});

router.post ('/add', upload.single ('photo'), (req, res) => {
  User.create ({
    fullName: req.body.fullName,
    email: req.body.email,
    password: req.body.password,
    photo: !req.file ? 'placeholder.jpg' : req.file.filename,
  })
    .then (user => {
      res.status (201).send (user);
    })
    .catch (err => {
      res.render ('error', err);
    });
});

//get data
router.get ('/userlist', (req, res) => {
  console.log (req);
  User.findAll ()
    .then (users => res.status (201).send (users))
    .catch (err => console.log (err));
});

module.exports = router;
