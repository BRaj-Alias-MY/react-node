import React, { Component } from 'react'

export class ListEmployees extends Component {
  render() {
    return (
        <React.Fragment>
        <h2>List Employees</h2>
        </React.Fragment>
    )
  }
}

export default ListEmployees
